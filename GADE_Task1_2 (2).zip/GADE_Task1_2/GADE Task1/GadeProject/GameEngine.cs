﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class GameEngine 
    {
        public Label maplabel = new Label();
        private Map map;

        public Map MAP
        {
            get { return map; }
            set { map = value; }
        }
        public GameEngine()
        {
            MAP = new Map(10, 20, 10, 20, 1, 2);
            
        }
        //a boolean to check whether character will be able to move
        public bool MovePlayer(Character.MovementEnum direction)
        {
            
            MAP.Player.Move(direction);
            MAP.Maps[MAP.Player.Y, MAP.Player.X] = new Hero(MAP.Player.X, MAP.Player.Y, Tile.TileType.Hero);

            if(MAP.Player.ReturnMove(direction) == direction )
            {
                if(direction == Character.MovementEnum.Up)
                {
                    MAP.Maps[MAP.Player.Y+1, MAP.Player.X] = new EmptyTile(MAP.Player.X, MAP.Player.Y+1, Tile.TileType.Empty);
                    
                    if(MAP.Player.Vision is Gold)
                    {
                        MAP.Player.Pickup(MAP.getGetItemAtPosition(MAP.Player.X, MAP.Player.Y));
                    }
                }

                if (direction == Character.MovementEnum.Down)
                {
                    MAP.Maps[MAP.Player.Y - 1, MAP.Player.X] = new EmptyTile(MAP.Player.X, MAP.Player.Y - 1, Tile.TileType.Empty);

                    if (MAP.Player.Vision is Gold)
                    {
                        MAP.Player.Pickup(MAP.getGetItemAtPosition(MAP.Player.X, MAP.Player.Y));
                    }
                }

                if (direction == Character.MovementEnum.Right)
                {
                    MAP.Maps[MAP.Player.Y, MAP.Player.X+1] = new EmptyTile(MAP.Player.X+1, MAP.Player.Y , Tile.TileType.Empty);

                    if (MAP.Player.Vision is Gold)
                    {
                        MAP.Player.Pickup(MAP.getGetItemAtPosition(MAP.Player.X, MAP.Player.Y));
                    }
                }

                if (direction == Character.MovementEnum.Left)
                {
                    MAP.Maps[MAP.Player.Y , MAP.Player.X-1] = new EmptyTile(MAP.Player.X-1, MAP.Player.Y, Tile.TileType.Empty);

                    if (MAP.Player.Vision is Gold)
                    {
                        MAP.Player.Pickup(MAP.getGetItemAtPosition(MAP.Player.X, MAP.Player.Y));
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
           
           
        }
    }
}
