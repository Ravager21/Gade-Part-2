namespace GadeProject
{
    public partial class Form1 : Form
    {
        GameEngine Engine = new GameEngine();
        public Form1()
        {
            InitializeComponent();

            gMap.Text = Engine.MAP.FillMap();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            
            
        }
        public void updateform()
        {
            gMap.Text = Engine.MAP.ToString();
            //gMap.Text = Engine.MAP.;

        }
        //assigning actions to the buttons for movement 
        private void BtnUp_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Up);
            
            gMap.Text = Engine.MAP.FillMap();
        }

        private void BtnRight_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Right);

            gMap.Text = Engine.MAP.FillMap();
        }

        private void BtnDown_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Down);

            gMap.Text = Engine.MAP.FillMap();
        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Left);

            gMap.Text = Engine.MAP.FillMap();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}