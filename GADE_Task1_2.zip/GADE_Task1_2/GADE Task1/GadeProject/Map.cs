﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Map
    {
        Enemy[] Enemies;
        protected Hero PLAYER;
        protected Tile[,] mapContainer;
        public Tile[,] Maps { get { return mapContainer; } set { mapContainer = value; } }
        public int mapWidth;
        public int mapHeight;

        Random number = new Random();
        public Hero Player { get { return PLAYER; } set { PLAYER = value; } }

        //added Mage and Gold but have no value as of yet.
        readonly string Hero = "H", SwampC = "SC", Empty = "_", Obstacle = "X", Mage = "M", Gold ="G";
        //generating the map size 
        public Map(int minWidth, int maxWidth, int minHeight, int maxHeight, int NumOfEnemies)
        {
            mapWidth = number.Next(minWidth, maxWidth);

            mapHeight = number.Next(minHeight, maxHeight);
            mapContainer = new Tile[mapWidth, mapHeight];
            for (int i = 0; i < mapHeight; i++)
            {
                for(int j = 0; j < mapWidth; j++)
                {
                    if((i == 0 || i == mapHeight - 1) || (j == 0 || j == mapWidth - 1))
                    {
                        mapContainer[j,i] = new Obstacle(i,j,Tile.TileType.Obstacle);
                    }
                    else
                    {
                        mapContainer[j, i] = new EmptyTile(i,j,Tile.TileType.Empty);
                    }
                }
            }

            

            Enemies = new Enemy[NumOfEnemies];

            PLAYER = (Hero)Create(Tile.TileType.Hero);

            for (int i = 0; i < Enemies.Length; i++)
            {
                Enemies[i] = (Enemy)Create(Tile.TileType.Enemy);
            }

        }
        //creating different tile type objects, for respawning 
        private Tile Create(Tile.TileType Type)
        {
            int yran = 0, xran = 0;
            bool loop = true;
            while(loop )
            {
                yran = number.Next(1,mapHeight -1);
                xran = number.Next(1,mapWidth -1);  
                if (mapContainer[yran,xran] is EmptyTile)
                {
                    loop = false;
                }
                else
                {
                    loop = true;
                }
            }
            if (Type == Tile.TileType.Hero)
            {
                Hero hero = new Hero(xran, yran, 10, 10,Tile.TileType.Hero);
                mapContainer[hero.Y, hero.X] = hero;
                return Player;
            }
            else if (Type == Tile.TileType.Enemy)
            {
                SwampCreatures newEnemy = new SwampCreatures(xran, yran);
                mapContainer[yran, xran] = newEnemy;
                return newEnemy;
            }
            return null;

        }
        public void UpdateVision(Character target)
        {
            target.Vision[0] = mapContainer[target.Y-1, target.X];//north
            target.Vision[1] = mapContainer[target.Y+1, target.X];//south
            target.Vision[2] = mapContainer[target.Y, target.X-1];//left
            target.Vision[3] = mapContainer[target.Y, target.X+1];//right
        }

        public string FillMap()
        {
            string map = "";
            for(int i = 0; i < mapContainer.GetLength(1); i++)
            {
                for(int j = 0; j < mapContainer.GetLength(1); j++)
                {
                    if(mapContainer[i, j] is Obstacle)
                    {
                        map += Obstacle; 
                    }
                    if (mapContainer[i, j] is EmptyTile)
                    {
                        map += Empty;
                    }
                    if (mapContainer[i, j] is Hero)
                    {
                        map += Hero;
                    }
                    if (mapContainer[i, j] is SwampCreatures)
                    {
                        map += SwampC;
                    }
                    map += "";
                }
                map += Environment.NewLine; 
            }
            return map;
        }
        
    }
}
