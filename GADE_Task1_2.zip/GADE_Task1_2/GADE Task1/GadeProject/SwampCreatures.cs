﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class SwampCreatures : Enemy
    {
        //Swamp Creature, an enemy
        public SwampCreatures(int x, int y) : base (x, y, 1, TileType.Enemy, 10, 10, "SC")
        {
            

        }
        //Movement for the swamp creature 
        public override MovementEnum ReturnMove(MovementEnum movement)
        {
            int space = 0;
            int RandMovement = num.Next(5);
            MovementEnum EnemyMove = (MovementEnum)RandMovement;
            if(space == 0)
            {
                return MovementEnum.NoMovement;
            }

            while(space > 0)
            {
                if (EnemyMove == MovementEnum.Up)
                {
                    if ((!(this.Vision[0] is Character)) && (!(this.Vision[0] is Obstacle)))
                    {
                        return MovementEnum.Up;
                    }

                }
                if (EnemyMove == MovementEnum.Down)
                {
                    if ((!(this.Vision[1] is Character)) && (!(this.Vision[1] is Obstacle)))
                    {
                        return MovementEnum.Down;
                    }
                }

                if (EnemyMove == MovementEnum.Left)
                {
                    if ((!(this.Vision[2] is Character)) && (!(this.Vision[2] is Obstacle)))
                    {
                        return MovementEnum.Left;
                    }
                }

                if (EnemyMove == MovementEnum.Right)
                {
                    if ((!(this.Vision[3] is Character)) && (!(this.Vision[3] is Obstacle)))
                    {
                        return MovementEnum.Right;
                    }
                }
                EnemyMove = (MovementEnum)(num.Next(4) + 1);
            }
            return MovementEnum.NoMovement;
        }
    }
}
