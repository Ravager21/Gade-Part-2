﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class Hero : Character
    {
        //Hero constructor
        public Hero(int x, int y, int Hp, int maxHp,Tile.TileType type) : base(x, y, type)
        {
            this.Hp = Hp;
            this.maxHp = maxHp;
            this.Damage = 2;
        }
        //Hero movement
        public override MovementEnum ReturnMove(MovementEnum HeroMove)
        {
            if (HeroMove == MovementEnum.Up)
            {
                if ((!(this.Vision[0] is Character)) && (!(this.Vision[0] is Obstacle)))
                {
                    return MovementEnum.Up;
                }

            }
            if (HeroMove == MovementEnum.Down)
            {
                //if (Vision[0] is EmptyTile)
                //{

                //}
                if ((!(this.Vision[1] is Character)) && (!(this.Vision[1] is Obstacle)))
                {
                    return MovementEnum.Down;
                }
            }

            if (HeroMove == MovementEnum.Left)
            {
                if ((!(this.Vision[2] is Character)) && (!(this.Vision[2] is Obstacle)))
                {
                    return MovementEnum.Left;
                }
            }

            if (HeroMove == MovementEnum.Right)
            {
                if ((!(this.Vision[3] is Character)) && (!(this.Vision[3] is Obstacle)))
                {
                    return MovementEnum.Right;
                }
            }
            return MovementEnum.NoMovement;
        }
        public override string ToString()
        {
            return "Player stats: \n" + "HP: " + Hp.ToString() + "\n Damage: " + Damage.ToString()
                + "[" + x.ToString() + "," + y.ToString() + "]";
        }
    }
}
