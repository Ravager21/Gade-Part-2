namespace GadeProject
{
    public partial class Form1 : Form
    {
        GameEngine Engine = new GameEngine();
        public Form1()
        {
            InitializeComponent();
            Map map = new Map(10, 11, 10, 11, 4);
            textBox1.Text = map.FillMap();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            gMap.Text = Engine.MAP.ToString();
            
        }
        //assigning actions to the buttons for movement 
        private void BtnUp_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Up);

            gMap.Text = Engine.MAP.ToString();
        }

        private void BtnRight_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Right);

            gMap.Text = Engine.MAP.ToString();
        }

        private void BtnDown_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Down);

            gMap.Text = Engine.MAP.ToString();
        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            Engine.MovePlayer(Character.MovementEnum.Left);

            gMap.Text = Engine.MAP.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}