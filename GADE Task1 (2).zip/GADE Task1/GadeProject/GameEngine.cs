﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GadeProject
{
    internal class GameEngine 
    {
        public Label maplabel = new Label();
        private Map map;
        public Map MAP
        {
            get { return map; }
            set { map = value; }
        }
        public GameEngine()
        {
            MAP = new Map(10, 20, 10, 20, 5);
            
        }
        //a boolean to check whether character will be able to move
        public bool MovePlayer(Character.MovementEnum direction)
        {
            Character.MovementEnum DIRECTION = MAP.Player.ReturnMove(direction);
            if (DIRECTION == direction)
            {
                MAP.Player.Move(direction);
                return true;
            }

            else

            {
                return false;
            }
        }
    }
}
